// Minimal client-side enhancements (lazy hydration placeholder)
document.addEventListener('DOMContentLoaded', () => {
  // Future: filtering, sorting etc.
});


